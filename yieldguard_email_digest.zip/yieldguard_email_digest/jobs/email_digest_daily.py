"""Daily ops digest. Run via Render Cron: `python -m jobs.email_digest_daily`"""
import logging
import sys
from datetime import date
from pathlib import Path
from jinja2 import Environment, FileSystemLoader

from app import create_app  # adjust to your factory
from config import DIGEST_RECIPIENTS
from jobs.digest_lib import queries
from jobs.digest_lib.mailer import send_email

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

TEMPLATE_DIR = Path(__file__).parent / "digest_lib" / "templates"


def build_daily_context() -> dict:
    return {
        "today_str": date.today().strftime("%A, %d %B %Y"),
        "overdue_temps": queries.overdue_temp_logs(),
        "temp_breaches": queries.out_of_range_temps_last_24h(),
        "overdue_cleaning": queries.overdue_cleaning_tasks(),
        "pest_open": queries.pest_issues_open(),
        "deliveries": queries.deliveries_today(),
        "prep": queries.todays_prep(),
        "low_stock": queries.low_stock_items(),
        "expiring_certs": queries.expiring_certs_soon(),
    }


def main() -> int:
    app = create_app()
    with app.app_context():
        try:
            ctx = build_daily_context()
        except Exception:
            logger.exception("Failed to build digest context")
            return 1

        env = Environment(loader=FileSystemLoader(TEMPLATE_DIR), autoescape=True)
        html = env.get_template("daily.html").render(**ctx)

        recipients = [r["email"] for r in DIGEST_RECIPIENTS if r.get("role") in ("manager", "staff")]
        subject = f"YieldGuard Daily Brief — {ctx['today_str']}"

        try:
            send_email(recipients, subject, html)
        except Exception:
            logger.exception("Failed to send daily digest")
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
