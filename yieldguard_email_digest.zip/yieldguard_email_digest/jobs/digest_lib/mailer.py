"""Resend email wrapper. Single send_email() call, fails loud on misconfig."""
import logging
import resend
from config import RESEND_API_KEY, DIGEST_FROM_EMAIL, DIGEST_FROM_NAME

logger = logging.getLogger(__name__)


def send_email(to_emails: list[str], subject: str, html: str, reply_to: str | None = None) -> dict:
    """
    Send an HTML email via Resend.
    Returns the Resend response dict on success, raises on failure.
    """
    if not RESEND_API_KEY:
        raise RuntimeError("RESEND_API_KEY not set in environment")
    if not to_emails:
        logger.warning("send_email called with empty recipient list, skipping")
        return {"skipped": True}

    resend.api_key = RESEND_API_KEY

    params: dict = {
        "from": f"{DIGEST_FROM_NAME} <{DIGEST_FROM_EMAIL}>",
        "to": to_emails,
        "subject": subject,
        "html": html,
    }
    if reply_to:
        params["reply_to"] = reply_to

    response = resend.Emails.send(params)
    logger.info(f"Email sent to {len(to_emails)} recipient(s): {response.get('id')}")
    return response
