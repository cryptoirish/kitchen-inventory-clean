"""All DB queries for the digests. Pure functions returning dicts/lists.

NOTE: Table/column names below are best guesses based on the YieldGuard module
descriptions. Adjust to match your actual schema before deploying.
"""
from datetime import date, datetime, timedelta
from sqlalchemy import text
from app import db  # adjust import to wherever your SQLAlchemy db lives
from config import (
    LOW_STOCK_THRESHOLD_DAYS,
    CERT_EXPIRY_WARNING_DAYS,
    TEMP_LOG_OVERDUE_HOURS,
)


# ---------- DAILY ----------

def overdue_temp_logs() -> list[dict]:
    """Fridges/freezers/hot-holds without a recent temperature log."""
    sql = text("""
        SELECT
            tp.id,
            tp.name,
            tp.location,
            MAX(tl.logged_at) AS last_logged
        FROM temperature_points tp
        LEFT JOIN temperature_logs tl ON tl.point_id = tp.id
        WHERE tp.active = TRUE
        GROUP BY tp.id, tp.name, tp.location
        HAVING MAX(tl.logged_at) IS NULL
            OR MAX(tl.logged_at) < NOW() - (:hours || ' hours')::interval
        ORDER BY last_logged NULLS FIRST
    """)
    rows = db.session.execute(sql, {"hours": TEMP_LOG_OVERDUE_HOURS}).mappings().all()
    return [dict(r) for r in rows]


def out_of_range_temps_last_24h() -> list[dict]:
    """Temp logs in the last 24h that breached min/max."""
    sql = text("""
        SELECT
            tp.name,
            tp.location,
            tl.temperature_c,
            tl.logged_at,
            tp.min_c,
            tp.max_c
        FROM temperature_logs tl
        JOIN temperature_points tp ON tp.id = tl.point_id
        WHERE tl.logged_at >= NOW() - INTERVAL '24 hours'
          AND (tl.temperature_c < tp.min_c OR tl.temperature_c > tp.max_c)
        ORDER BY tl.logged_at DESC
    """)
    return [dict(r) for r in db.session.execute(sql).mappings().all()]


def overdue_cleaning_tasks() -> list[dict]:
    sql = text("""
        SELECT
            ct.id,
            ct.name,
            ct.frequency,
            MAX(cl.completed_at) AS last_done,
            ct.next_due_at
        FROM cleaning_tasks ct
        LEFT JOIN cleaning_logs cl ON cl.task_id = ct.id
        WHERE ct.active = TRUE
          AND (ct.next_due_at IS NULL OR ct.next_due_at <= NOW())
        GROUP BY ct.id, ct.name, ct.frequency, ct.next_due_at
        ORDER BY ct.next_due_at NULLS FIRST
    """)
    return [dict(r) for r in db.session.execute(sql).mappings().all()]


def deliveries_today() -> list[dict]:
    sql = text("""
        SELECT supplier, expected_at, status
        FROM deliveries
        WHERE DATE(expected_at) = CURRENT_DATE
        ORDER BY expected_at
    """)
    return [dict(r) for r in db.session.execute(sql).mappings().all()]


def pest_issues_open() -> list[dict]:
    sql = text("""
        SELECT id, location, description, reported_at, severity
        FROM pest_reports
        WHERE resolved_at IS NULL
        ORDER BY severity DESC, reported_at ASC
    """)
    return [dict(r) for r in db.session.execute(sql).mappings().all()]


def low_stock_items() -> list[dict]:
    """Items below threshold (par level or days-of-cover)."""
    sql = text("""
        SELECT
            i.name,
            i.unit,
            i.current_qty,
            i.par_level,
            i.avg_daily_usage,
            CASE
                WHEN i.avg_daily_usage > 0
                THEN ROUND((i.current_qty / i.avg_daily_usage)::numeric, 1)
                ELSE NULL
            END AS days_cover
        FROM inventory_items i
        WHERE i.active = TRUE
          AND (
              i.current_qty < i.par_level
              OR (i.avg_daily_usage > 0 AND i.current_qty / i.avg_daily_usage < :days)
          )
        ORDER BY days_cover NULLS FIRST
    """)
    return [dict(r) for r in db.session.execute(sql, {"days": LOW_STOCK_THRESHOLD_DAYS}).mappings().all()]


def todays_prep() -> list[dict]:
    """Recipes flagged for today's service."""
    sql = text("""
        SELECT r.name, ps.qty, ps.notes
        FROM prep_schedule ps
        JOIN recipes r ON r.id = ps.recipe_id
        WHERE ps.prep_date = CURRENT_DATE
        ORDER BY r.name
    """)
    return [dict(r) for r in db.session.execute(sql).mappings().all()]


def expiring_certs_soon() -> list[dict]:
    sql = text("""
        SELECT
            s.name AS staff_name,
            c.cert_type,
            c.expires_on,
            (c.expires_on - CURRENT_DATE) AS days_left
        FROM staff_certifications c
        JOIN staff s ON s.id = c.staff_id
        WHERE c.expires_on <= CURRENT_DATE + (:days || ' days')::interval
          AND s.active = TRUE
        ORDER BY c.expires_on ASC
    """)
    rows = db.session.execute(sql, {"days": CERT_EXPIRY_WARNING_DAYS}).mappings().all()
    return [dict(r) for r in rows]


# ---------- WEEKLY ----------

def weekly_gp_summary() -> dict:
    """Average GP%, revenue, COGS for the last 7 days, by menu category."""
    sql = text("""
        SELECT
            m.category,
            SUM(ms.qty_sold * ms.sale_price) AS revenue,
            SUM(ms.qty_sold * m.food_cost)   AS cogs,
            CASE
              WHEN SUM(ms.qty_sold * ms.sale_price) > 0
              THEN ROUND(
                  ((SUM(ms.qty_sold * ms.sale_price) - SUM(ms.qty_sold * m.food_cost))
                   / SUM(ms.qty_sold * ms.sale_price) * 100)::numeric, 1)
              ELSE 0
            END AS gp_percent
        FROM menu_sales ms
        JOIN menu_items m ON m.id = ms.menu_item_id
        WHERE ms.sold_at >= NOW() - INTERVAL '7 days'
        GROUP BY m.category
        ORDER BY revenue DESC
    """)
    by_category = [dict(r) for r in db.session.execute(sql).mappings().all()]

    totals = {
        "revenue": sum(r["revenue"] or 0 for r in by_category),
        "cogs": sum(r["cogs"] or 0 for r in by_category),
    }
    totals["gp_percent"] = (
        round((totals["revenue"] - totals["cogs"]) / totals["revenue"] * 100, 1)
        if totals["revenue"] else 0
    )
    return {"by_category": by_category, "totals": totals}


def weekly_compliance_summary() -> dict:
    """HACCP completion rates for the past 7 days."""
    sql = text("""
        SELECT
            (SELECT COUNT(*) FROM temperature_logs WHERE logged_at >= NOW() - INTERVAL '7 days') AS temp_logs_count,
            (SELECT COUNT(*) FROM cleaning_logs WHERE completed_at >= NOW() - INTERVAL '7 days') AS cleaning_logs_count,
            (SELECT COUNT(*) FROM temperature_logs tl
                JOIN temperature_points tp ON tp.id = tl.point_id
                WHERE tl.logged_at >= NOW() - INTERVAL '7 days'
                  AND (tl.temperature_c < tp.min_c OR tl.temperature_c > tp.max_c)
            ) AS temp_breaches,
            (SELECT COUNT(*) FROM pest_reports WHERE reported_at >= NOW() - INTERVAL '7 days') AS pest_reports_week
    """)
    row = db.session.execute(sql).mappings().first()
    return dict(row) if row else {}


def weekly_training_status() -> dict:
    """Cert summary: expired, expiring within 30 days, valid."""
    sql = text("""
        SELECT
            COUNT(*) FILTER (WHERE expires_on < CURRENT_DATE) AS expired,
            COUNT(*) FILTER (WHERE expires_on BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days') AS expiring_soon,
            COUNT(*) FILTER (WHERE expires_on > CURRENT_DATE + INTERVAL '30 days') AS valid
        FROM staff_certifications c
        JOIN staff s ON s.id = c.staff_id
        WHERE s.active = TRUE
    """)
    return dict(db.session.execute(sql).mappings().first() or {})
