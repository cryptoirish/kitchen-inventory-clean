"""Weekly manager report. Run via Render Cron Mondays: `python -m jobs.email_digest_weekly`"""
import logging
import sys
from datetime import date, datetime
from pathlib import Path
from jinja2 import Environment, FileSystemLoader

from app import create_app
from config import DIGEST_RECIPIENTS, GP_TARGET_PERCENT
from jobs.digest_lib import queries
from jobs.digest_lib.mailer import send_email

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

TEMPLATE_DIR = Path(__file__).parent / "digest_lib" / "templates"


def build_weekly_context() -> dict:
    return {
        "today_str": date.today().strftime("%d %B %Y"),
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "gp_target": GP_TARGET_PERCENT,
        "gp": queries.weekly_gp_summary(),
        "compliance": queries.weekly_compliance_summary(),
        "training": queries.weekly_training_status(),
    }


def main() -> int:
    app = create_app()
    with app.app_context():
        try:
            ctx = build_weekly_context()
        except Exception:
            logger.exception("Failed to build weekly context")
            return 1

        env = Environment(loader=FileSystemLoader(TEMPLATE_DIR), autoescape=True)
        html = env.get_template("weekly.html").render(**ctx)

        recipients = [r["email"] for r in DIGEST_RECIPIENTS if r.get("role") == "manager"]
        subject = f"YieldGuard Weekly Report — w/e {ctx['today_str']}"

        try:
            send_email(recipients, subject, html)
        except Exception:
            logger.exception("Failed to send weekly digest")
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
