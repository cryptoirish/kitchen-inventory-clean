# =============================================================================
# APPEND THIS BLOCK TO YOUR EXISTING config.py
# =============================================================================
import os

# --- Email digest settings ---
RESEND_API_KEY = os.environ.get("RESEND_API_KEY")
DIGEST_FROM_EMAIL = os.environ.get("DIGEST_FROM_EMAIL", "[email protected]")
DIGEST_FROM_NAME = os.environ.get("DIGEST_FROM_NAME", "YieldGuard")

# Hardcoded for now — migrate to a `digest_subscribers` table later.
# Format: list of dicts so we can add role/preference columns without restructuring.
DIGEST_RECIPIENTS = [
    {"email": "[email protected]", "name": "Head Chef", "role": "manager"},
    # {"email": "[email protected]", "name": "Sous Chef", "role": "manager"},
]

# --- Thresholds — tune these to your operation ---
LOW_STOCK_THRESHOLD_DAYS = 3      # flag items with <3 days cover
CERT_EXPIRY_WARNING_DAYS = 30     # flag certs expiring within 30 days
TEMP_LOG_OVERDUE_HOURS = 4        # flag fridges/freezers without log in 4hrs
GP_TARGET_PERCENT = 65            # weekly GP% target for highlighting
