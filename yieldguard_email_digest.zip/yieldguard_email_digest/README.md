# YieldGuard Email Digest

Drop-in email digest module for the YieldGuard Flask app.

- **Daily ops digest** — HACCP alerts, deliveries, prep, low stock, expiring certs
- **Weekly manager report** — GP%, compliance summary, training status
- Sent via Resend, scheduled via Render Cron Jobs

---

## Install

### 1. Drop the `jobs/` folder into your project root

After unzipping, copy the `jobs/` directory into the root of your YieldGuard Flask project (same level as `app.py` / `config.py` / `requirements.txt`).

Final layout:

```
yieldguard/
├── app.py
├── config.py
├── requirements.txt
├── jobs/
│   ├── __init__.py
│   ├── email_digest_daily.py
│   ├── email_digest_weekly.py
│   └── digest_lib/
│       ├── __init__.py
│       ├── mailer.py
│       ├── queries.py
│       └── templates/
│           ├── daily.html
│           └── weekly.html
```

### 2. Append `requirements_snippet.txt` to your `requirements.txt`

```
resend==2.4.0
jinja2>=3.1.0
```

(Jinja2 is already installed if you're using Flask — listed for clarity.)

### 3. Append `config_snippet.py` to your existing `config.py`

This adds Resend settings, the recipient list, and the alert thresholds.

### 4. Set up Resend

1. Sign up at https://resend.com (free tier: 3,000 emails/month).
2. Add your sending domain and verify the DNS records (SPF, DKIM). The dashboard walks you through it. **Don't skip this** — unverified-domain emails go to spam.
3. Create an API key.

### 5. Set environment variables on Render

On both the web service AND the two cron jobs you'll create:

```
RESEND_API_KEY=re_xxxxxxxxxxxxxx
[email protected]
DIGEST_FROM_NAME=YieldGuard
TZ=Europe/London
```

Setting `TZ=Europe/London` makes cron schedules behave in UK local time year-round (GMT/BST automatic).

### 6. Create the two Render Cron Jobs

In the Render dashboard, **New → Cron Job**, pointing at the same repo as the web service.

**Daily ops digest:**
- Name: `yieldguard-daily-digest`
- Command: `python -m jobs.email_digest_daily`
- Schedule: `0 7 * * *` (07:00 daily)

**Weekly manager report:**
- Name: `yieldguard-weekly-digest`
- Command: `python -m jobs.email_digest_weekly`
- Schedule: `0 7 * * 1` (07:00 every Monday)

---

## Test locally before deploying

```bash
export RESEND_API_KEY=re_xxx
export [email protected]
python -m jobs.email_digest_daily
```

If the import fails on `from app import create_app` or `from app import db`, see "Adjustments" below.

---

## Adjustments

### App factory import

`email_digest_daily.py` and `email_digest_weekly.py` start with:

```python
from app import create_app
```

Change this to wherever your Flask app factory lives. Common variants:

```python
from yieldguard import create_app          # if your package is named yieldguard
from app.factory import create_app         # if you split it out
from wsgi import app                       # if you have a singleton, not a factory
```

If you have a singleton `app` (no factory), the `main()` function changes slightly:

```python
from app import app

def main() -> int:
    with app.app_context():
        ...
```

### Database queries

`jobs/digest_lib/queries.py` uses raw SQL with table/column names guessed from your module list. The names you'll most likely need to adjust:

| Table assumed         | Columns assumed                                                |
| --------------------- | -------------------------------------------------------------- |
| `temperature_points`  | `id, name, location, min_c, max_c, active`                     |
| `temperature_logs`    | `point_id, temperature_c, logged_at`                           |
| `cleaning_tasks`      | `id, name, frequency, next_due_at, active`                     |
| `cleaning_logs`       | `task_id, completed_at`                                        |
| `deliveries`          | `supplier, expected_at, status`                                |
| `pest_reports`        | `id, location, description, reported_at, severity, resolved_at`|
| `inventory_items`     | `name, unit, current_qty, par_level, avg_daily_usage, active`  |
| `prep_schedule`       | `recipe_id, prep_date, qty, notes`                             |
| `recipes`             | `id, name`                                                     |
| `staff`               | `id, name, active`                                             |
| `staff_certifications`| `staff_id, cert_type, expires_on`                              |
| `menu_sales`          | `menu_item_id, qty_sold, sale_price, sold_at`                  |
| `menu_items`          | `id, category, food_cost`                                      |

If a query references a table you haven't built yet (e.g. you don't have `prep_schedule` or `menu_sales` populated), the query will return zero rows and the corresponding template section will show "no data" — it won't crash. Once you have the data, edit the SQL to match your actual columns.

### Recipient roles

In `config.py`, `DIGEST_RECIPIENTS` entries have a `role` field. The daily digest goes to anyone with role `manager` or `staff`. The weekly digest goes to `manager` only. Adjust roles per recipient.

### Migrating recipients to a database table later

When you're ready to make this table-driven, create a `digest_subscribers` table with columns matching the dict keys (`email`, `name`, `role`), then replace the `DIGEST_RECIPIENTS` import in both job scripts with a query that returns the same shape:

```python
def get_recipients():
    rows = db.session.execute(
        text("SELECT email, name, role FROM digest_subscribers WHERE active = TRUE")
    ).mappings().all()
    return [dict(r) for r in rows]
```

The rest of the code doesn't change.

---

## Troubleshooting

**"RESEND_API_KEY not set in environment"**
The cron job didn't inherit the env var. Set it explicitly on the cron job in the Render dashboard.

**Emails landing in spam**
Domain not verified, or `DIGEST_FROM_EMAIL` doesn't match the verified domain. Check DNS records on Resend's domain page.

**"relation does not exist" SQL errors**
Table name in `queries.py` doesn't match yours. Edit the SQL or alias your table.

**Cron runs in wrong timezone**
Set `TZ=Europe/London` env var on the cron job.

**Want to dry-run without sending**
Add this near the top of `mailer.py`:
```python
DRY_RUN = os.environ.get("DIGEST_DRY_RUN") == "1"
```
And in `send_email`:
```python
if DRY_RUN:
    logger.info(f"[DRY RUN] Would send to {to_emails}: {subject}")
    print(html)
    return {"dry_run": True}
```
Then run with `DIGEST_DRY_RUN=1 python -m jobs.email_digest_daily`.
